import React, { useState } from "react";

interface Choice {
  id: string;
  text: string;
  isCorrect: boolean;
}

const MultipleChoiceEditor: React.FC = () => {
  const [title, setTitle] = useState<string>("");
  const [points, setPoints] = useState<number>(0);
  const [question, setQuestion] = useState<string>("");
  const [choices, setChoices] = useState<Choice[]>([]);
  const [isEditing, setIsEditing] = useState<boolean>(true);

  const handleAddChoice = () => {
    setChoices([...choices, { id: Date.now().toString(), text: "", isCorrect: false }]);
  };

  const handleRemoveChoice = (id: string) => {
    setChoices(choices.filter(choice => choice.id !== id));
  };

  const handleChoiceChange = (id: string, text: string) => {
    setChoices(
      choices.map(choice => (choice.id === id ? { ...choice, text } : choice))
    );
  };

  const handleCorrectAnswerChange = (id: string) => {
    setChoices(
      choices.map(choice => ({ ...choice, isCorrect: choice.id === id }))
    );
  };

  const handleSave = () => {
    const questionData = {
      title,
      points,
      question,
      choices,
    };
    console.log("Question saved:", questionData);
    setIsEditing(false); // You can also perform additional actions, e.g., API calls
  };

  const handleCancel = () => {
    setTitle("");
    setPoints(0);
    setQuestion("");
    setChoices([]);
    setIsEditing(true);
  };

  return (
    <div>
      <h3>Multiple Choice Question Editor</h3>
      {isEditing ? (
        <form>
          <div>
            <label>Title:</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter the title of the question"
            />
          </div>
          <div>
            <label>Points:</label>
            <input
              type="number"
              value={points}
              onChange={(e) => setPoints(Number(e.target.value))}
              placeholder="Enter points for the question"
            />
          </div>
          <div>
            <label>Question:</label>
            <textarea
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Enter your question here"
            />
          </div>
          <div>
            <label>Choices:</label>
            {choices.length === 0 ? (
              <p>No choices added yet. Please add at least one choice.</p>
            ) : (
              choices.map((choice, index) => (
                <div key={choice.id} style={{ marginBottom: "10px" }}>
                  <input
                    type="text"
                    value={choice.text}
                    onChange={(e) => handleChoiceChange(choice.id, e.target.value)}
                    placeholder={`Choice ${index + 1}`}
                  />
                  <input
                    type="radio"
                    name="correctAnswer"
                    checked={choice.isCorrect}
                    onChange={() => handleCorrectAnswerChange(choice.id)}
                  />
                  <label>Correct Answer</label>
                  <button type="button" onClick={() => handleRemoveChoice(choice.id)}>
                    Remove
                  </button>
                </div>
              ))
            )}
            <button type="button" onClick={handleAddChoice}>
              Add Another Answer
            </button>
          </div>
          <div>
            <button type="button" onClick={handleCancel}>
              Cancel
            </button>
            <button type="button" onClick={handleSave}>
              Save/Update Question
            </button>
          </div>
        </form>
      ) : (
        <p>Question saved successfully. Edit again to make changes.</p>
      )}
    </div>
  );
}  