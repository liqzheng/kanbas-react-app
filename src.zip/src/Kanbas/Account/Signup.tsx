import React from "react";
import { Link } from "react-router-dom";
const Signup=()=> {
  return (
    <div id="wd-signup-screen">
      
      <h3>Sign up</h3>

      <input placeholder="username" /><br/>
      <input placeholder="password" type="password" /><br/>
      <input placeholder="verify password" type="password" /><br/>

      <label htmlFor="userType">I am a: </label>
      <select id="userType">
        <option value="professor">Professor</option>
        <option value="student">Student</option>
      </select>
      <br />
      <Link to="/Kanbas/Account/Profile" > Sign up </Link><br />
      <Link to="/Kanbas/Account/Signin" >Sign in</Link>
    </div>
);}
export default Signup;
